# MyPhone
Aplikasi Android (Kotlin + Jetpack Compose) bertema Anime Jepang.
- MyBox: pilih folder penyimpanan, buat folder kategori, putar video/musik, lihat foto
- Share: Bluetooth (RFCOMM) dan WiFi (QR + Scan)
Build: GitHub Actions -> Artifacts -> MyPhone-debug-apk
