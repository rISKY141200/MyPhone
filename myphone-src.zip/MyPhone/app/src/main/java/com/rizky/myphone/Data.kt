package com.rizky.myphone

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import java.io.*
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import kotlin.concurrent.thread

private val mainHandler = Handler(Looper.getMainLooper())
fun onMain(block: () -> Unit) { mainHandler.post(block) }

fun copyN(i: InputStream, o: OutputStream, size: Long, cb: (Float) -> Unit) {
    val buf = ByteArray(32 * 1024)
    var done = 0L
    while (size < 0 || done < size) {
        val want = if (size < 0) buf.size else minOf(buf.size.toLong(), size - done).toInt()
        val r = i.read(buf, 0, want)
        if (r < 0) break
        o.write(buf, 0, r)
        done += r
        if (size > 0) cb(done.toFloat() / size)
    }
    o.flush()
}

fun queryMeta(ctx: Context, u: Uri): Pair<String, Long> {
    var name = "file"
    var size = -1L
    ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val si = c.getColumnIndex(OpenableColumns.SIZE)
            if (ni >= 0) name = c.getString(ni) ?: name
            if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
        }
    }
    if (size < 0) size = ctx.contentResolver.openAssetFileDescriptor(u, "r")?.use { it.length } ?: 0L
    return name to size
}

fun localIp(): String? = try {
    NetworkInterface.getNetworkInterfaces().toList()
        .filter { it.isUp && !it.isLoopback }
        .flatMap { it.inetAddresses.toList() }
        .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }?.hostAddress
} catch (e: Exception) { null }

fun isLanHost(host: String): Boolean {
    val p = host.split(".").mapNotNull { it.toIntOrNull() }
    if (p.size != 4) return false
    return p[0] == 10 || (p[0] == 192 && p[1] == 168) || (p[0] == 172 && p[1] in 16..31)
}

class Store(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("myphone", Context.MODE_PRIVATE)
    var root: Uri?
        get() = prefs.getString("root", null)?.let { Uri.parse(it) }
        set(v) { prefs.edit().putString("root", v?.toString()).apply() }

    fun rootDoc(): DocumentFile? = root?.let { DocumentFile.fromTreeUri(ctx, it) }

    fun receivedDir(): DocumentFile? {
        val r = rootDoc() ?: return null
        return r.findFile("Diterima") ?: r.createDirectory("Diterima")
    }

    fun saveStream(dir: DocumentFile, name: String, input: InputStream, size: Long, cb: (Float) -> Unit) {
        val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val base = safe.substringBeforeLast('.', safe)
        val ext = safe.substringAfterLast('.', "")
        var final = safe
        var n = 1
        while (dir.findFile(final) != null) {
            final = if (ext.isEmpty()) "$base ($n)" else "$base ($n).$ext"
            n++
        }
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase()) ?: "application/octet-stream"
        val f = dir.createFile(mime, final) ?: error("Gagal membuat file")
        ctx.contentResolver.openOutputStream(f.uri)!!.use { out -> copyN(input, out, size, cb) }
    }

    fun receive(name: String, input: InputStream, size: Long, cb: (Float) -> Unit) {
        val dir = receivedDir() ?: error("Folder belum dipilih")
        saveStream(dir, name, input, size, cb)
    }

    fun importInto(dir: DocumentFile, u: Uri) {
        val (name, size) = queryMeta(ctx, u)
        ctx.contentResolver.openInputStream(u)!!.use { saveStream(dir, name, it, size) {} }
    }
}

// ---------- WiFi: server HTTP mini (pengirim), QR berisi alamatnya ----------
class FileServer(private val ctx: Context, private val files: List<Uri>) {
    private var ss: ServerSocket? = null
    private val meta = files.map { queryMeta(ctx, it) }

    fun start(): Int {
        val s = ServerSocket(0)
        ss = s
        thread(isDaemon = true) {
            while (!s.isClosed) {
                try { val c = s.accept(); thread(isDaemon = true) { handle(c) } } catch (e: Exception) { break }
            }
        }
        return s.localPort
    }

    fun stop() { try { ss?.close() } catch (_: Exception) {} }

    private fun handle(c: Socket) {
        try {
            c.use {
                val line = it.getInputStream().bufferedReader().readLine() ?: return
                val path = line.split(" ").getOrNull(1) ?: return
                val out = BufferedOutputStream(it.getOutputStream())
                if (path == "/list") {
                    val body = meta.mapIndexed { i, m -> "$i\t${m.first}\t${m.second}" }.joinToString("\n").toByteArray()
                    out.write("HTTP/1.1 200 OK\r\nContent-Length: ${body.size}\r\nConnection: close\r\n\r\n".toByteArray())
                    out.write(body)
                } else if (path.startsWith("/f/")) {
                    val i = path.removePrefix("/f/").toIntOrNull()
                    if (i == null || i !in files.indices) {
                        out.write("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n".toByteArray())
                    } else {
                        out.write("HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Length: ${meta[i].second}\r\nConnection: close\r\n\r\n".toByteArray())
                        ctx.contentResolver.openInputStream(files[i])?.use { ins -> ins.copyTo(out) }
                    }
                }
                out.flush()
            }
        } catch (_: Exception) {}
    }
}

// ---------- Bluetooth klasik (RFCOMM) ----------
val APP_UUID: UUID = UUID.fromString("8f0f0b1a-3c52-4a6e-9d11-4b6a7a1c2e01")
