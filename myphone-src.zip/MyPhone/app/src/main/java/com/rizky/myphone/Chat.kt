package com.rizky.myphone

import android.annotation.SuppressLint
import android.app.*
import android.bluetooth.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.concurrent.thread

data class ChatMsg(val mine: Boolean, val text: String)

object Links {
    lateinit var ctx: Context
    lateinit var store: Store
    @Volatile var visible = false
    private var inited = false

    fun init(c: Context) {
        if (inited) return
        inited = true
        ctx = c.applicationContext
        store = Store(ctx)
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("link_session", "Sesi koneksi", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel("link_msg", "Pesan masuk", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    fun maybeStopService() {
        if (!BtHub.isBusy() && !WifiHub.isBusy()) ctx.stopService(Intent(ctx, LinkService::class.java))
    }
}

/**
 * Sesi chat + kirim file di atas satu koneksi (Bluetooth atau WiFi).
 * Protokol: 1 = teks, 2 = file (nama, ukuran, isi), 3 = nama perangkat, 0 = putus.
 */
open class ChatHub(private val id: String) {
    val messages = mutableStateListOf<ChatMsg>()
    var status by mutableStateOf("")
    var progress by mutableStateOf(0f)
    var connected by mutableStateOf<String?>(null)
    var listening by mutableStateOf(false)

    @Volatile protected var listenActive = false
    @Volatile private var sock: Closeable? = null
    @Volatile private var out: DataOutputStream? = null
    @Volatile private var currentKey: String? = null
    private val exec = Executors.newSingleThreadExecutor()
    private val ioExec = Executors.newSingleThreadExecutor()

    fun isBusy() = listenActive || sock != null

    private fun histFile(key: String) =
        File(Links.ctx.filesDir, "chat_${id}_" + key.replace(Regex("[^A-Za-z0-9]"), "_") + ".json")

    private fun loadHistory(key: String): List<ChatMsg> = try {
        val f = histFile(key)
        if (!f.exists()) emptyList() else {
            val arr = JSONArray(f.readText())
            List(arr.length()) { i -> arr.getJSONObject(i).let { ChatMsg(it.getBoolean("m"), it.getString("t")) } }
        }
    } catch (e: Exception) { emptyList() }

    private fun saveHistory(key: String, list: List<ChatMsg>) {
        try {
            val arr = JSONArray()
            list.forEach { arr.put(JSONObject().put("m", it.mine).put("t", it.text)) }
            histFile(key).writeText(arr.toString())
        } catch (_: Exception) {}
    }

    /** Panggil di thread utama. */
    private fun addMsg(m: ChatMsg) {
        messages.add(m)
        while (messages.size > 500) messages.removeAt(0)
        val key = currentKey ?: return
        val snap = messages.toList()
        ioExec.execute { saveHistory(key, snap) }
    }

    fun clearHistory() {
        messages.clear()
        val key = currentKey ?: return
        ioExec.execute { try { histFile(key).delete() } catch (_: Exception) {} }
    }

    protected fun session(c: Closeable, ins: InputStream, outs: OutputStream, name: String, key: String) {
        sock = c
        currentKey = key
        val hist = loadHistory(key)
        val input = DataInputStream(BufferedInputStream(ins))
        val o = DataOutputStream(BufferedOutputStream(outs))
        out = o
        onMain { messages.clear(); messages.addAll(hist); connected = name; status = "Terhubung"; progress = 0f }
        exec.execute { try { o.writeByte(3); o.writeUTF(Build.MODEL ?: "Perangkat"); o.flush() } catch (_: Exception) {} }
        try {
            while (true) {
                when (input.readByte().toInt()) {
                    1 -> {
                        val t = input.readUTF()
                        onMain { addMsg(ChatMsg(false, t)) }
                        notifyIncoming(t)
                    }
                    2 -> {
                        val fn = input.readUTF()
                        val size = input.readLong()
                        onMain { status = "Menerima $fn"; progress = 0.001f }
                        Links.store.receive(fn, input, size) { p -> onMain { progress = p } }
                        onMain { addMsg(ChatMsg(false, "📎 $fn (disimpan di folder Diterima)")); status = "Terhubung"; progress = 0f }
                        notifyIncoming("📎 $fn")
                    }
                    3 -> { val n = input.readUTF(); onMain { if (connected != null) connected = n } }
                    else -> break
                }
            }
        } catch (_: Exception) {}
        closeSession("Koneksi terputus")
    }

    private fun closeSession(msg: String) {
        try { sock?.close() } catch (_: Exception) {}
        sock = null; out = null
        onMain { connected = null; status = msg; progress = 0f }
        Links.maybeStopService()
    }

    protected fun fail(msg: String) {
        onMain { status = msg }
        Links.maybeStopService()
    }

    fun sendText(t: String) {
        val o = out ?: return
        if (t.isBlank()) return
        exec.execute {
            try {
                o.writeByte(1); o.writeUTF(t); o.flush()
                onMain { addMsg(ChatMsg(true, t)) }
            } catch (e: Exception) { closeSession("Gagal kirim, koneksi putus") }
        }
    }

    fun sendFile(u: Uri) {
        val o = out ?: return
        exec.execute {
            try {
                val (name, size) = queryMeta(Links.ctx, u)
                o.writeByte(2); o.writeUTF(name); o.writeLong(size)
                onMain { status = "Mengirim $name"; progress = 0.001f }
                Links.ctx.contentResolver.openInputStream(u)!!.use { ins ->
                    copyN(ins, o, size) { p -> onMain { progress = p } }
                }
                o.flush()
                onMain { addMsg(ChatMsg(true, "📎 $name (terkirim)")); status = "Terhubung"; progress = 0f }
            } catch (e: Exception) { closeSession("Gagal kirim file, koneksi putus") }
        }
    }

    fun disconnect() {
        val o = out
        exec.execute {
            try { o?.writeByte(0); o?.flush() } catch (_: Exception) {}
            closeSession("Sambungan diputus")
        }
    }

    private fun notifyIncoming(text: String) {
        if (Links.visible) return
        val ctx = Links.ctx
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = NotificationCompat.Builder(ctx, "link_msg")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(connected ?: "MyPhone").setContentText(text)
                .setContentIntent(open).setAutoCancel(true).build()
            NotificationManagerCompat.from(ctx).notify(if (id == "bt") 2 else 3, n)
        } catch (_: Exception) {}
    }
}

@SuppressLint("MissingPermission")
object BtHub : ChatHub("bt") {
    private var adapter: BluetoothAdapter? = null
    private var server: BluetoothServerSocket? = null

    private fun ad(): BluetoothAdapter? {
        if (adapter == null) adapter = (Links.ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        return adapter
    }

    fun listen() {
        val a = ad() ?: return
        if (connected != null) return
        stopListen()
        LinkService.start(Links.ctx)
        listenActive = true
        onMain { listening = true; status = "Menunggu sambungan…" }
        thread(isDaemon = true) {
            try {
                val s = a.listenUsingRfcommWithServiceRecord("MyPhone", APP_UUID)
                server = s
                val c = s.accept()
                s.close(); server = null; listenActive = false
                onMain { listening = false }
                val d = c.remoteDevice
                session(c, c.inputStream, c.outputStream, d.name ?: d.address, d.address)
            } catch (e: Exception) {
                listenActive = false
                onMain { listening = false; if (connected == null) status = "Berhenti menunggu" }
                Links.maybeStopService()
            }
        }
    }

    fun stopListen() {
        try { server?.close() } catch (_: Exception) {}
        server = null
    }

    fun connect(dev: BluetoothDevice) {
        val a = ad() ?: return
        if (connected != null) return
        stopListen()
        LinkService.start(Links.ctx)
        onMain { status = "Menghubungkan ke ${dev.name ?: dev.address}…" }
        thread(isDaemon = true) {
            try {
                a.cancelDiscovery()
                val s = dev.createRfcommSocketToServiceRecord(APP_UUID)
                s.connect()
                session(s, s.inputStream, s.outputStream, dev.name ?: dev.address, dev.address)
            } catch (e: Exception) {
                fail("Gagal tersambung. Pastikan HP tujuan sudah memilih “Tunggu sambungan”.")
            }
        }
    }
}

object WifiHub : ChatHub("wifi") {
    var hostCode by mutableStateOf<String?>(null)
    private var server: ServerSocket? = null

    fun host() {
        if (connected != null) return
        stopHost()
        val ip = localIp()
        if (ip == null) { onMain { status = "Sambungkan ke WiFi atau hotspot dulu" }; return }
        val s = try { ServerSocket(WIFI_PORT) } catch (e: Exception) {
            try { ServerSocket(0) } catch (e2: Exception) { onMain { status = "Gagal membuka koneksi" }; return }
        }
        server = s
        listenActive = true
        LinkService.start(Links.ctx)
        onMain { hostCode = "$ip:${s.localPort}"; listening = true; status = "Menunggu HP lain memindai QR…" }
        thread(isDaemon = true) {
            try {
                val c = s.accept()
                try { s.close() } catch (_: Exception) {}
                server = null; listenActive = false
                onMain { listening = false; hostCode = null }
                val addr = c.inetAddress.hostAddress ?: "HP lain"
                session(c, c.getInputStream(), c.getOutputStream(), addr, addr)
            } catch (e: Exception) {
                listenActive = false
                onMain { listening = false; hostCode = null; if (connected == null) status = "Berhenti menunggu" }
                Links.maybeStopService()
            }
        }
    }

    fun stopHost() {
        try { server?.close() } catch (_: Exception) {}
        server = null
    }

    fun join(raw: String) {
        if (connected != null) return
        val hp = parseHostPort(raw)
        if (hp == null) { onMain { status = "Kode tidak valid atau bukan jaringan lokal" }; return }
        LinkService.start(Links.ctx)
        onMain { status = "Menyambung ke ${hp.first}…" }
        thread(isDaemon = true) {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(hp.first, hp.second), 8000)
                session(s, s.getInputStream(), s.getOutputStream(), hp.first, hp.first)
            } catch (e: Exception) {
                fail("Gagal menyambung. Pastikan kedua HP di WiFi yang sama.")
            }
        }
    }
}

class LinkService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "STOP") {
            BtHub.stopListen(); WifiHub.stopHost()
            BtHub.disconnect(); WifiHub.disconnect()
            stopSelf()
            return START_NOT_STICKY
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, LinkService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "link_session")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("MyPhone aktif")
            .setContentText("Chat & transfer berjalan di latar belakang")
            .setContentIntent(open).addAction(0, "Hentikan", stop).setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            else startForeground(1, n)
        } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    companion object {
        fun start(ctx: Context) {
            try { ContextCompat.startForegroundService(ctx, Intent(ctx, LinkService::class.java)) } catch (_: Exception) {}
        }
    }
}
