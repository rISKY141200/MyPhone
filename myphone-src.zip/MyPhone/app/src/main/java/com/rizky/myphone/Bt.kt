package com.rizky.myphone

import android.annotation.SuppressLint
import android.app.*
import android.bluetooth.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.util.concurrent.Executors
import kotlin.concurrent.thread

data class ChatMsg(val mine: Boolean, val text: String)

/**
 * Pusat koneksi Bluetooth. Hidup selama proses hidup (dijaga BtService),
 * jadi chat & transfer tetap jalan walau layar ditutup / pindah aplikasi.
 * Protokol: 1 = teks (UTF), 2 = file (nama, ukuran, isi), 0 = putus.
 */
@SuppressLint("MissingPermission")
object BtHub {
    val messages = mutableStateListOf<ChatMsg>()
    var status by mutableStateOf("")
    var progress by mutableStateOf(0f)
    var connected by mutableStateOf<String?>(null)
    var listening by mutableStateOf(false)
    @Volatile var appVisible = false

    private lateinit var appCtx: Context
    private lateinit var store: Store
    private var adapter: BluetoothAdapter? = null
    private var server: BluetoothServerSocket? = null
    private var sock: BluetoothSocket? = null
    private var out: DataOutputStream? = null
    @Volatile private var listenActive = false
    private val exec = Executors.newSingleThreadExecutor()
    private val ioExec = Executors.newSingleThreadExecutor()
    @Volatile private var currentKey: String? = null

    private fun histFile(key: String) =
        File(appCtx.filesDir, "chat_" + key.replace(Regex("[^A-Za-z0-9]"), "_") + ".json")

    private fun loadHistory(key: String): List<ChatMsg> = try {
        val f = histFile(key)
        if (!f.exists()) emptyList() else {
            val arr = JSONArray(f.readText())
            List(arr.length()) { i -> arr.getJSONObject(i).let { ChatMsg(it.getBoolean("m"), it.getString("t")) } }
        }
    } catch (e: Exception) { emptyList() }

    private fun saveHistory(key: String, list: List<ChatMsg>) {
        try {
            val arr = JSONArray()
            list.forEach { arr.put(JSONObject().put("m", it.mine).put("t", it.text)) }
            histFile(key).writeText(arr.toString())
        } catch (_: Exception) {}
    }

    /** Harus dipanggil di thread utama. */
    private fun addMsg(m: ChatMsg) {
        messages.add(m)
        while (messages.size > 500) messages.removeAt(0)
        val key = currentKey ?: return
        val snap = messages.toList()
        ioExec.execute { saveHistory(key, snap) }
    }

    fun clearHistory() {
        messages.clear()
        val key = currentKey ?: return
        ioExec.execute { try { histFile(key).delete() } catch (_: Exception) {} }
    }

    fun init(ctx: Context) {
        if (::appCtx.isInitialized) return
        appCtx = ctx.applicationContext
        store = Store(appCtx)
        adapter = (appCtx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = appCtx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("bt_session", "Sesi Bluetooth", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel("bt_msg", "Pesan Bluetooth", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    fun listen() {
        val a = adapter ?: return
        if (connected != null) return
        stopListen()
        BtService.start(appCtx)
        listenActive = true
        onMain { listening = true; status = "Menunggu sambungan…" }
        thread(isDaemon = true) {
            try {
                val s = a.listenUsingRfcommWithServiceRecord("MyPhone", APP_UUID)
                server = s
                val c = s.accept()
                s.close(); server = null; listenActive = false
                onMain { listening = false }
                session(c, c.remoteDevice.name ?: c.remoteDevice.address, c.remoteDevice.address)
            } catch (e: Exception) {
                listenActive = false
                onMain { listening = false; if (connected == null) status = "Berhenti menunggu" }
                maybeStopService()
            }
        }
    }

    fun stopListen() {
        try { server?.close() } catch (_: Exception) {}
        server = null
    }

    fun connect(dev: BluetoothDevice) {
        val a = adapter ?: return
        if (connected != null) return
        stopListen()
        BtService.start(appCtx)
        onMain { status = "Menghubungkan ke ${dev.name ?: dev.address}…" }
        thread(isDaemon = true) {
            try {
                a.cancelDiscovery()
                val s = dev.createRfcommSocketToServiceRecord(APP_UUID)
                s.connect()
                session(s, dev.name ?: dev.address, dev.address)
            } catch (e: Exception) {
                onMain { status = "Gagal: ${e.message}. Pastikan HP tujuan menekan Terima." }
                maybeStopService()
            }
        }
    }

    private fun session(s: BluetoothSocket, name: String, key: String) {
        sock = s
        currentKey = key
        val hist = loadHistory(key)
        val input = DataInputStream(BufferedInputStream(s.inputStream))
        out = DataOutputStream(BufferedOutputStream(s.outputStream))
        onMain { messages.clear(); messages.addAll(hist); connected = name; status = "Terhubung ke $name"; progress = 0f }
        try {
            while (true) {
                when (input.readByte().toInt()) {
                    1 -> {
                        val t = input.readUTF()
                        onMain { addMsg(ChatMsg(false, t)) }
                        notifyIncoming(name, t)
                    }
                    2 -> {
                        val fn = input.readUTF()
                        val size = input.readLong()
                        onMain { status = "Menerima $fn"; progress = 0.001f }
                        store.receive(fn, input, size) { p -> onMain { progress = p } }
                        onMain { addMsg(ChatMsg(false, "📎 $fn (disimpan di Diterima)")); status = "Terhubung ke $name"; progress = 0f }
                        notifyIncoming(name, "📎 $fn")
                    }
                    else -> break
                }
            }
        } catch (_: Exception) {}
        closeSession("Koneksi terputus")
    }

    private fun closeSession(msg: String) {
        try { sock?.close() } catch (_: Exception) {}
        sock = null; out = null
        onMain { connected = null; status = msg; progress = 0f }
        maybeStopService()
    }

    private fun maybeStopService() {
        if (!listenActive && sock == null) appCtx.stopService(Intent(appCtx, BtService::class.java))
    }

    fun sendText(t: String) {
        val o = out ?: return
        if (t.isBlank()) return
        exec.execute {
            try {
                o.writeByte(1); o.writeUTF(t); o.flush()
                onMain { addMsg(ChatMsg(true, t)) }
            } catch (e: Exception) { closeSession("Gagal kirim, koneksi putus") }
        }
    }

    fun sendFile(u: Uri) {
        val o = out ?: return
        exec.execute {
            try {
                val (name, size) = queryMeta(appCtx, u)
                o.writeByte(2); o.writeUTF(name); o.writeLong(size)
                onMain { status = "Mengirim $name"; progress = 0.001f }
                appCtx.contentResolver.openInputStream(u)!!.use { ins ->
                    copyN(ins, o, size) { p -> onMain { progress = p } }
                }
                o.flush()
                onMain { addMsg(ChatMsg(true, "📎 $name (terkirim)")); status = "Terhubung ke ${connected ?: ""}"; progress = 0f }
            } catch (e: Exception) { closeSession("Gagal kirim file, koneksi putus") }
        }
    }

    fun disconnect() {
        val o = out
        exec.execute {
            try { o?.writeByte(0); o?.flush() } catch (_: Exception) {}
            closeSession("Terputus")
        }
    }

    private fun notifyIncoming(who: String, text: String) {
        if (appVisible) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(appCtx, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val open = PendingIntent.getActivity(appCtx, 0, Intent(appCtx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = NotificationCompat.Builder(appCtx, "bt_msg")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(who).setContentText(text)
                .setContentIntent(open).setAutoCancel(true).build()
            NotificationManagerCompat.from(appCtx).notify(2, n)
        } catch (_: Exception) {}
    }
}

class BtService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "STOP") {
            BtHub.stopListen(); BtHub.disconnect(); stopSelf()
            return START_NOT_STICKY
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, BtService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "bt_session")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("MyPhone Bluetooth aktif")
            .setContentText("Chat & transfer berjalan di latar belakang")
            .setContentIntent(open).addAction(0, "Hentikan", stop).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        else startForeground(1, n)
        return START_NOT_STICKY
    }

    companion object {
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, BtService::class.java))
        }
    }
}
