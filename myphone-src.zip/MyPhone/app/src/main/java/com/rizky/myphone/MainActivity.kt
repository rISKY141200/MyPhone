package com.rizky.myphone

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BtHub.init(applicationContext)
        setContent { MyPhoneTheme { App() } }
    }

    override fun onStart() { super.onStart(); BtHub.appVisible = true }
    override fun onStop() { super.onStop(); BtHub.appVisible = false }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var screen by remember { mutableStateOf("home") }
    var hasRoot by remember { mutableStateOf(store.root != null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            store.root = uri
            hasRoot = true
        }
    }
    BackHandler(enabled = screen == "bt" || screen == "wifi" || screen == "share") {
        screen = if (screen == "share") "home" else "share"
    }
    SakuraBackground {
        when (screen) {
            "home" -> Home(hasRoot, { pick.launch(null) }, { screen = "box" }, { screen = "share" })
            "box" -> BoxScreen(store) { screen = "home" }
            "share" -> ShareHome({ screen = "home" }, { screen = "bt" }, { screen = "wifi" })
            "bt" -> BtScreen(store) { screen = "share" }
            "wifi" -> WifiScreen(store) { screen = "share" }
        }
    }
}
