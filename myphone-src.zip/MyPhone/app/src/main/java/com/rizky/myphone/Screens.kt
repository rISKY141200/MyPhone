package com.rizky.myphone

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Build
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.rotate as rotateDraw
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.compose.AsyncImage
import com.google.zxing.BarcodeFormat
import com.google.zxing.ResultPoint
import com.journeyapps.barcodescanner.BarcodeCallback
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.journeyapps.barcodescanner.BarcodeResult
import com.journeyapps.barcodescanner.DecoratedBarcodeView
import kotlinx.coroutines.delay
import java.io.File
import kotlin.concurrent.thread

// ======================= Komponen umum =======================

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) IconButton(onClick = onBack) { Icon(Ic.Back, "Kembali", tint = Color.White) }
        else Spacer(Modifier.width(12.dp))
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Color.White, maxLines = 1, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
fun MenuCard(icon: ImageVector, title: String, sub: String, tint: Color = Accent, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "press")
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().scale(scale).clip(shape).background(Color(0x14FFFFFF))
            .border(1.dp, Color(0x22FFFFFF), shape)
            .clickable(interactionSource = src, indication = null, onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(tint.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            Text(sub, fontSize = 13.sp, color = TextDim)
        }
        Text("›", fontSize = 26.sp, color = TextDim)
    }
}

@Composable
fun PrimaryButton(text: String, icon: ImageVector? = null, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(50.dp)) {
        if (icon != null) { Icon(icon, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun OutlineButton(text: String, icon: ImageVector? = null, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(50.dp)) {
        if (icon != null) { Icon(icon, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ProgressBar(p: Float) {
    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x33FFFFFF))) {
        Box(Modifier.fillMaxWidth(p.coerceIn(0f, 1f)).fillMaxHeight().background(Accent))
    }
}

@Composable
fun InfoCard(text: String, color: Color = TextDim) {
    Text(
        text, color = color, fontSize = 13.sp,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x14FFFFFF)).padding(14.dp)
    )
}

@Composable
fun SectionLabel(text: String) {
    Text(text, color = TextDim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp, modifier = Modifier.padding(top = 6.dp))
}

@Composable
fun Logo(size: Int = 48) {
    val acc = Accent
    Box(Modifier.size(size.dp).clip(RoundedCornerShape(14.dp)).background(Color(0x22FFFFFF)), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size((size * 0.7f).dp)) {
            val c = center
            val w = this.size.width
            for (i in 0 until 5) {
                rotateDraw(i * 72f, c) {
                    drawOval(acc, topLeft = Offset(c.x - w * 0.12f, c.y - w * 0.46f), size = Size(w * 0.24f, w * 0.4f))
                }
            }
            drawCircle(Gold, w * 0.08f, c)
        }
    }
}

// ======================= Beranda & Pengaturan =======================

@Composable
fun Home(hasRoot: Boolean, pickFolder: () -> Unit, openBox: () -> Unit, openShare: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Logo()
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("MyPhone", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Simpan & bagikan file dengan mudah", fontSize = 13.sp, color = TextDim)
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Ic.MoreVert, "Pengaturan", tint = Color.White) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Ganti folder penyimpanan") }, onClick = { menu = false; pickFolder() })
                    DropdownMenuItem(text = { Text("Ganti warna tema") }, onClick = { menu = false; dialog = "theme" })
                    DropdownMenuItem(text = { Text("Ganti background chat") }, onClick = { menu = false; dialog = "chatbg" })
                    DropdownMenuItem(text = { Text("Laporan error terakhir") }, onClick = { menu = false; dialog = "crash" })
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (!hasRoot) {
                InfoCard("Pilih folder penyimpanan dulu supaya MyBox dan Share bisa dipakai.", Gold)
                PrimaryButton("Pilih folder penyimpanan", Ic.Folder, onClick = pickFolder)
            }
            MenuCard(Ic.Folder, "MyBox", "Kelola, putar, dan lihat file-mu", Gold) { if (hasRoot) openBox() else pickFolder() }
            MenuCard(Ic.Share, "Share", "Chat & kirim file lewat Bluetooth atau WiFi", Accent) { if (hasRoot) openShare() else pickFolder() }
        }
    }
    when (dialog) {
        "theme" -> ThemeDialog { dialog = "" }
        "chatbg" -> ChatBgDialog { dialog = "" }
        "crash" -> CrashDialog { dialog = "" }
    }
}

@Composable
fun ThemeDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Warna tema") },
        text = {
            Column {
                THEMES.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        row.forEach { (name, c) ->
                            val idx = THEMES.indexOfFirst { it.first == name }
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable { UiPrefs.setTheme(idx); onDismiss() }.padding(8.dp)
                            ) {
                                Box(
                                    Modifier.size(44.dp).clip(CircleShape).background(c)
                                        .border(if (UiPrefs.themeIdx == idx) 3.dp else 0.dp, Color.White, CircleShape)
                                )
                                Text(name, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup") } }
    )
}

@Composable
fun ChatBgDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            thread {
                try {
                    ctx.filesDir.listFiles()?.filter { it.name.startsWith("chatbg_") }?.forEach { it.delete() }
                    val f = File(ctx.filesDir, "chatbg_${System.currentTimeMillis()}.img")
                    ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    onMain { UiPrefs.setChatBg("img:" + f.absolutePath) }
                } catch (e: Exception) { onMain { Toast.makeText(ctx, "Gagal memuat gambar", Toast.LENGTH_SHORT).show() } }
            }
            onDismiss()
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Background chat") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Berlaku untuk chat Bluetooth dan WiFi.", fontSize = 13.sp, color = TextDim)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CHAT_COLORS.forEach { hex ->
                        val sel = UiPrefs.chatBg == "c:$hex"
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(Color(android.graphics.Color.parseColor(hex)))
                                .border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color(0x55FFFFFF), CircleShape)
                                .clickable { UiPrefs.setChatBg("c:$hex"); onDismiss() }
                        )
                    }
                }
                OutlineButton("Pilih gambar dari galeri", Ic.Image) { pick.launch(arrayOf("image/*")) }
                TextButton(onClick = { UiPrefs.setChatBg("default"); onDismiss() }) { Text("Kembalikan ke bawaan") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup") } }
    )
}

@Composable
fun CrashDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val f = remember { File(ctx.filesDir, "last_crash.txt") }
    val text = remember { if (f.exists()) f.readText() else "" }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Laporan error terakhir") },
        text = {
            if (text.isEmpty()) Text("Belum ada error tercatat.")
            else Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                Text(text, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        },
        confirmButton = {
            if (text.isNotEmpty()) TextButton(onClick = {
                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("crash", text))
                Toast.makeText(ctx, "Disalin", Toast.LENGTH_SHORT).show()
            }) { Text("Salin") }
        },
        dismissButton = {
            Row {
                if (text.isNotEmpty()) TextButton(onClick = { f.delete(); onDismiss() }) { Text("Hapus") }
                TextButton(onClick = onDismiss) { Text("Tutup") }
            }
        }
    )
}

// ======================= MyBox =======================

fun iconFor(f: DocumentFile): Pair<ImageVector, Color> {
    val m = f.type ?: ""
    return when {
        f.isDirectory -> Ic.Folder to Gold
        m.startsWith("image") -> Ic.Image to Mint
        m.startsWith("video") -> Ic.Movie to Color(0xFF64B5F6)
        m.startsWith("audio") -> Ic.Music to Color(0xFFB388FF)
        else -> Ic.File to TextDim
    }
}

@Composable
fun BoxScreen(store: Store, onExit: () -> Unit) {
    val root = remember { store.rootDoc() }
    val ctx = LocalContext.current
    var stack by remember { mutableStateOf(listOfNotNull(root)) }
    var tick by remember { mutableStateOf(0) }
    var opened by remember { mutableStateOf<DocumentFile?>(null) }
    var showNew by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<DocumentFile?>(null) }
    var deleting by remember { mutableStateOf<DocumentFile?>(null) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val dir = stack.lastOrNull()
        if (dir != null && uris.isNotEmpty()) {
            thread { uris.forEach { runCatching { store.importInto(dir, it) } }; onMain { tick++ } }
        }
    }
    BackHandler {
        if (opened != null) opened = null
        else if (stack.size > 1) stack = stack.dropLast(1)
        else onExit()
    }
    val cur = stack.lastOrNull()
    if (cur == null) { Text("Folder tidak ditemukan", color = Color.White, modifier = Modifier.padding(24.dp)); return }
    val items = remember(cur, tick) {
        cur.listFiles().sortedWith(compareBy({ !it.isDirectory }, { it.name?.lowercase() }))
    }
    val o = opened
    if (o != null) { Viewer(o) { opened = null }; return }

    Column(Modifier.fillMaxSize()) {
        TopBar(if (stack.size == 1) "MyBox" else cur.name ?: "Folder", onBack = {
            if (stack.size > 1) stack = stack.dropLast(1) else onExit()
        })
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilledTonalButton(onClick = { showNew = true }, shape = RoundedCornerShape(12.dp)) {
                Icon(Ic.Folder, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Folder baru")
            }
            FilledTonalButton(onClick = { importer.launch(arrayOf("*/*")) }, shape = RoundedCornerShape(12.dp)) {
                Icon(Ic.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Tambah file")
            }
        }
        Spacer(Modifier.height(10.dp))
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Belum ada isi.\nBuat folder kategori seperti Anime, Musik, atau Dokumen.", color = TextDim, textAlign = TextAlign.Center, modifier = Modifier.padding(32.dp))
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.uri.toString() }) { f ->
                    FileRow(
                        f,
                        onOpen = { if (f.isDirectory) stack = stack + f else opened = f },
                        onRename = { renaming = f },
                        onDelete = { deleting = f }
                    )
                }
            }
        }
    }
    if (showNew) NewFolderDialog(onDismiss = { showNew = false }) { name ->
        showNew = false
        cur.createDirectory(name)
        tick++
    }
    renaming?.let { f ->
        RenameDialog(f.name ?: "", { renaming = null }) { n ->
            renaming = null
            val ok = runCatching { f.renameTo(n) }.getOrDefault(false)
            if (!ok) Toast.makeText(ctx, "Gagal mengganti nama", Toast.LENGTH_SHORT).show()
            tick++
        }
    }
    deleting?.let { f ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Hapus ${f.name}?") },
            text = { Text(if (f.isDirectory) "Folder beserta semua isinya akan terhapus permanen." else "File akan terhapus permanen.") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    val ok = runCatching { f.delete() }.getOrDefault(false)
                    if (!ok) Toast.makeText(ctx, "Gagal menghapus", Toast.LENGTH_SHORT).show()
                    tick++
                }) { Text("Hapus", color = Color(0xFFFF6B6B)) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Batal") } }
        )
    }
}

@Composable
fun FileRow(f: DocumentFile, onOpen: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val (ic, col) = iconFor(f)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0x14FFFFFF))
            .clickable(onClick = onOpen).padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(col.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            Icon(ic, null, tint = col, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(f.name ?: "?", color = Color.White, maxLines = 2, modifier = Modifier.weight(1f))
        Box {
            IconButton(onClick = { menu = true }) { Icon(Ic.MoreVert, "Menu", tint = TextDim) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Ganti nama") }, onClick = { menu = false; onRename() })
                DropdownMenuItem(text = { Text("Hapus") }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

@Composable
fun NewFolderDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Folder kategori baru") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Nama folder") })
                Row { listOf("Anime", "Musik", "Dokumen").forEach { s -> TextButton(onClick = { name = s }) { Text(s, fontSize = 12.sp) } } }
                Row { listOf("Foto", "Video").forEach { s -> TextButton(onClick = { name = s }) { Text(s, fontSize = 12.sp) } } }
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onCreate(name.trim()) }) { Text("Buat") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
fun RenameDialog(current: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ganti nama") },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
        confirmButton = { TextButton(enabled = name.isNotBlank() && name != current, onClick = { onOk(name.trim()) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
fun Viewer(f: DocumentFile, onClose: () -> Unit) {
    val mime = f.type ?: ""
    Column(Modifier.fillMaxSize()) {
        TopBar(f.name ?: "", onClose)
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            when {
                mime.startsWith("image") -> AsyncImage(model = f.uri, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                mime.startsWith("video") -> AndroidView(
                    factory = { c ->
                        VideoView(c).apply {
                            val mc = MediaController(c)
                            mc.setAnchorView(this)
                            setMediaController(mc)
                            setVideoURI(f.uri)
                            setOnPreparedListener { start() }
                        }
                    },
                    onRelease = { it.stopPlayback() },
                    modifier = Modifier.fillMaxSize()
                )
                mime.startsWith("audio") -> AudioPlayer(f)
                else -> Text("Format ini belum bisa dibuka di MyBox", color = Color.White)
            }
        }
    }
}

@Composable
fun AudioPlayer(f: DocumentFile) {
    val ctx = LocalContext.current
    val mp = remember { MediaPlayer().apply { setDataSource(ctx, f.uri); prepare() } }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0f) }
    DisposableEffect(Unit) { onDispose { mp.release() } }
    LaunchedEffect(playing) {
        while (playing) {
            pos = mp.currentPosition.toFloat()
            if (!mp.isPlaying) playing = false
            delay(250)
        }
    }
    val spin by rememberInfiniteTransition(label = "disc").animateFloat(
        0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "spin"
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
        Box(Modifier.size(180.dp).rotate(if (playing) spin else 0f).clip(CircleShape).background(Accent.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
            Icon(Ic.Music, null, tint = Accent, modifier = Modifier.size(80.dp))
        }
        Spacer(Modifier.height(24.dp))
        Slider(
            value = pos, valueRange = 0f..mp.duration.toFloat().coerceAtLeast(1f),
            onValueChange = { pos = it }, onValueChangeFinished = { mp.seekTo(pos.toInt()) }
        )
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.size(64.dp).clip(CircleShape).background(Accent).clickable {
                if (playing) { mp.pause(); playing = false } else { mp.start(); playing = true }
            },
            contentAlignment = Alignment.Center
        ) { Icon(if (playing) Ic.Pause else Ic.Play, null, tint = Night, modifier = Modifier.size(32.dp)) }
    }
}

// ======================= Share =======================

@Composable
fun ShareHome(onBack: () -> Unit, openBt: () -> Unit, openWifi: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar("Share", onBack)
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            MenuCard(Ic.Bluetooth, "Bluetooth", "Chat & kirim file ke HP terpasang", Color(0xFF64B5F6), openBt)
            MenuCard(Ic.Wifi, "WiFi", "Sambung lewat QR di jaringan yang sama", Mint, openWifi)
            InfoCard("File yang diterima otomatis masuk ke folder “Diterima” di MyBox. Sambungan tetap aktif di latar belakang.")
        }
    }
}

@Composable
fun ChatBackground(content: @Composable BoxScope.() -> Unit) {
    val bg = UiPrefs.chatBg
    Box(Modifier.fillMaxSize()) {
        when {
            bg.startsWith("c:") -> {
                val c = runCatching { Color(android.graphics.Color.parseColor(bg.removePrefix("c:"))) }.getOrDefault(Night)
                Box(Modifier.fillMaxSize().background(c))
            }
            bg.startsWith("img:") -> {
                AsyncImage(model = File(bg.removePrefix("img:")), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Color(0x66000000)))
            }
        }
        content()
    }
}

@Composable
fun ChatScreen(hub: ChatHub, onBack: () -> Unit, pickFile: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val msgs = hub.messages
    val who = hub.connected ?: ""
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }
    ChatBackground {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().background(Color(0x77000000)).padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Ic.Back, "Kembali", tint = Color.White) }
                Box(Modifier.size(40.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
                    Text(who.take(1).uppercase(), color = Night, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(who, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text("Terhubung", color = Mint, fontSize = 12.sp)
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Ic.MoreVert, "Menu", tint = Color.White) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Hapus riwayat") }, onClick = { menu = false; confirmClear = true })
                        DropdownMenuItem(text = { Text("Putuskan sambungan") }, onClick = { menu = false; hub.disconnect() })
                    }
                }
            }
            if (hub.progress > 0f) {
                Column(Modifier.fillMaxWidth().background(Color(0x77000000)).padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(hub.status, fontSize = 12.sp, color = Color.White)
                    Spacer(Modifier.height(4.dp))
                    ProgressBar(hub.progress)
                }
            }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), state = listState,
                verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(msgs.size) { i ->
                    val m = msgs[i]
                    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.mine) Alignment.CenterEnd else Alignment.CenterStart) {
                        Text(
                            m.text, color = if (m.mine) Night else Color.White,
                            modifier = Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(18.dp))
                                .background(if (m.mine) Accent else Color(0xCC26243A)).padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                }
            }
            Row(Modifier.fillMaxWidth().background(Color(0x99000000)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = pickFile) { Icon(Ic.Attach, "Lampirkan file", tint = Color.White) }
                OutlinedTextField(
                    value = text, onValueChange = { if (it.length <= 2000) text = it },
                    modifier = Modifier.weight(1f), placeholder = { Text("Ketik pesan…") },
                    maxLines = 3, shape = RoundedCornerShape(24.dp)
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.size(46.dp).clip(CircleShape).background(if (text.isBlank()) Color(0x44FFFFFF) else Accent)
                        .clickable(enabled = text.isNotBlank()) { hub.sendText(text.trim()); text = "" },
                    contentAlignment = Alignment.Center
                ) { Icon(Ic.Send, "Kirim", tint = Night, modifier = Modifier.size(22.dp)) }
            }
        }
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Hapus riwayat chat?") },
        text = { Text("Semua pesan dengan perangkat ini akan dihapus dari HP ini.") },
        confirmButton = { TextButton(onClick = { confirmClear = false; hub.clearHistory() }) { Text("Hapus", color = Color(0xFFFF6B6B)) } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Batal") } }
    )
}

@Composable
fun StatusBanner(hub: ChatHub) {
    if (hub.status.isNotEmpty()) InfoCard(hub.status, Mint)
}

fun hasBtPerm(ctx: Context) =
    Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

@SuppressLint("MissingPermission")
@Composable
fun BtScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val adapter = remember { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter }
    var granted by remember { mutableStateOf(hasBtPerm(ctx)) }
    var tick by remember { mutableStateOf(0) }
    val perms = remember {
        buildList {
            if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = hasBtPerm(ctx) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> uris.forEach { BtHub.sendFile(it) } }

    if (BtHub.connected != null) {
        ChatScreen(BtHub, onBack) { pick.launch(arrayOf("*/*")) }
    } else {
        Column(Modifier.fillMaxSize()) {
            TopBar("Bluetooth", onBack)
            Column(Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when {
                    adapter == null -> InfoCard("Perangkat ini tidak punya Bluetooth.")
                    !granted -> {
                        InfoCard("Izinkan akses Bluetooth agar bisa menyambung.")
                        PrimaryButton("Izinkan", Ic.Bluetooth) { perm.launch(perms) }
                    }
                    !adapter.isEnabled -> {
                        InfoCard("Bluetooth masih mati.", Gold)
                        PrimaryButton("Nyalakan Bluetooth", Ic.Bluetooth) { ctx.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }
                        OutlineButton("Sudah menyala, cek lagi") { tick++ }
                    }
                    else -> {
                        StatusBanner(BtHub)
                        SectionLabel("LANGKAH 1 — DI HP PENERIMA")
                        if (BtHub.listening) OutlineButton("Menunggu… ketuk untuk batal") { BtHub.stopListen() }
                        else PrimaryButton("Tunggu sambungan", Ic.Bluetooth) { BtHub.listen() }
                        SectionLabel("LANGKAH 2 — DI HP LAIN, KETUK NAMA PERANGKAT")
                        val devices = remember(tick, granted) { adapter.bondedDevices.toList() }
                        devices.forEach { d ->
                            MenuCard(Ic.Bluetooth, d.name ?: d.address, "Ketuk untuk menyambung", Color(0xFF64B5F6)) { BtHub.connect(d) }
                        }
                        if (devices.isEmpty()) InfoCard("Belum ada perangkat terpasang. Pasangkan dulu di pengaturan Bluetooth.", Gold)
                        TextButton(onClick = { ctx.startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                            Text("Pasangkan perangkat baru")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QrScanner(onResult: (String) -> Unit) {
    val owner = LocalLifecycleOwner.current
    val holder = remember { arrayOfNulls<DecoratedBarcodeView>(1) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> holder[0]?.resume()
                Lifecycle.Event.ON_PAUSE -> holder[0]?.pause()
                else -> {}
            }
        }
        owner.lifecycle.addObserver(obs)
        holder[0]?.resume()
        onDispose { owner.lifecycle.removeObserver(obs); holder[0]?.pause() }
    }
    AndroidView(
        factory = { c ->
            DecoratedBarcodeView(c).apply {
                setStatusText("")
                decodeContinuous(object : BarcodeCallback {
                    override fun barcodeResult(result: BarcodeResult?) { result?.text?.let(onResult) }
                    override fun possibleResultPoints(resultPoints: MutableList<ResultPoint>?) {}
                })
                holder[0] = this
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
fun WifiScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var mode by remember { mutableStateOf("menu") }
    var code by remember { mutableStateOf("") }
    var hasCam by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    var scanned by remember { mutableStateOf(false) }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCam = it }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> uris.forEach { WifiHub.sendFile(it) } }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    DisposableEffect(Unit) { onDispose { if (WifiHub.connected == null) WifiHub.stopHost() } }
    BackHandler(enabled = mode != "menu" && WifiHub.connected == null) {
        WifiHub.stopHost(); scanned = false; mode = "menu"
    }

    if (WifiHub.connected != null) {
        ChatScreen(WifiHub, onBack) { pick.launch(arrayOf("*/*")) }
        return
    }
    Column(Modifier.fillMaxSize()) {
        val topBack: () -> Unit = if (mode == "menu") onBack else ({ WifiHub.stopHost(); scanned = false; mode = "menu" })
        TopBar("WiFi", topBack)
        Column(Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            when (mode) {
                "menu" -> {
                    StatusBanner(WifiHub)
                    MenuCard(Ic.Qr, "Buat sambungan", "Tampilkan QR untuk dipindai HP lain", Mint) { mode = "host"; WifiHub.host() }
                    MenuCard(Ic.Wifi, "Gabung ke HP lain", "Pindai QR atau ketik kode", Color(0xFF64B5F6)) { mode = "join" }
                    InfoCard("Pastikan kedua HP terhubung ke WiFi atau hotspot yang sama.")
                }
                "host" -> {
                    val c = WifiHub.hostCode
                    if (c != null) {
                        val bmp = remember(c) { BarcodeEncoder().encodeBitmap("myphone://$c", BarcodeFormat.QR_CODE, 700, 700) }
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Image(
                                bitmap = bmp.asImageBitmap(), contentDescription = "QR",
                                modifier = Modifier.size(260.dp).clip(RoundedCornerShape(20.dp)).background(Color.White).padding(10.dp)
                            )
                        }
                        Text("Atau ketik kode ini di HP lain:", color = TextDim, fontSize = 13.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                        Text(c.substringBefore(":"), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.align(Alignment.CenterHorizontally))
                    }
                    StatusBanner(WifiHub)
                    OutlineButton("Batal") { WifiHub.stopHost(); mode = "menu" }
                }
                else -> {
                    if (!hasCam) {
                        InfoCard("Izin kamera diperlukan untuk memindai QR.")
                        PrimaryButton("Izinkan kamera", Ic.Qr) { camPerm.launch(Manifest.permission.CAMERA) }
                    } else {
                        Box(Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(20.dp))) {
                            QrScanner { text ->
                                if (!scanned) { scanned = true; WifiHub.join(text) }
                            }
                        }
                    }
                    SectionLabel("ATAU KETIK KODE DARI HP LAIN")
                    OutlinedTextField(
                        value = code, onValueChange = { code = it }, singleLine = true,
                        label = { Text("Contoh: 192.168.1.5") }, modifier = Modifier.fillMaxWidth()
                    )
                    PrimaryButton("Sambungkan", enabled = code.isNotBlank()) { WifiHub.join(code) }
                    StatusBanner(WifiHub)
                }
            }
        }
    }
}
