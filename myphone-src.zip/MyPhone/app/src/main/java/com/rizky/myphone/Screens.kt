package com.rizky.myphone

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import com.google.zxing.BarcodeFormat
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.delay
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

// ---------- komponen umum ----------
@Composable
fun TopBar(title: String, onBack: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) TextButton(onClick = onBack) { Text("◀", fontSize = 20.sp, color = Sakura) }
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, modifier = Modifier.weight(1f))
    }
}

@Composable
fun AnimeCard(jp: String, title: String, sub: String, accent: Color, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.95f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "press")
    val shape = RoundedCornerShape(28.dp)
    Row(
        Modifier.fillMaxWidth().scale(scale).clip(shape).background(Color(0x33FFFFFF))
            .border(BorderStroke(2.dp, accent), shape)
            .clickable(interactionSource = src, indication = null, onClick = onClick).padding(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(68.dp).clip(CircleShape).background(accent), contentAlignment = Alignment.Center) {
            Text(jp, fontSize = 32.sp, color = Night, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(sub, fontSize = 13.sp, color = Color(0xFFD9CFF5))
        }
    }
}

@Composable
fun ProgressBar(p: Float) {
    Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0x33FFFFFF))) {
        Box(Modifier.fillMaxWidth(p.coerceIn(0f, 1f)).fillMaxHeight().background(Sakura))
    }
}

@Composable
fun PinkButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().height(52.dp)
    ) { Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

// ---------- Beranda ----------
@Composable
fun Home(hasRoot: Boolean, pickFolder: () -> Unit, openBox: () -> Unit, openShare: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("マイフォン", color = Sakura, fontSize = 16.sp, letterSpacing = 6.sp)
        Text("MyPhone", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Black)
        Text(
            if (hasRoot) "Folder penyimpanan siap ✓" else "Pilih folder penyimpanan dulu ya~",
            color = if (hasRoot) Mint else Gold, fontSize = 14.sp
        )
        Spacer(Modifier.height(28.dp))
        AnimeCard("箱", "MyBox", "Simpan, putar & lihat file-mu", Sakura) { if (hasRoot) openBox() else pickFolder() }
        Spacer(Modifier.height(16.dp))
        AnimeCard("共", "Share", "Kirim lewat Bluetooth atau WiFi", Mint) { if (hasRoot) openShare() else pickFolder() }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = pickFolder, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text(if (hasRoot) "Ganti folder penyimpanan" else "Pilih folder penyimpanan", color = Gold)
        }
    }
}

// ---------- MyBox ----------
fun emojiFor(f: DocumentFile): String {
    val m = f.type ?: ""
    return when {
        f.isDirectory -> "📁"
        m.startsWith("image") -> "🖼️"
        m.startsWith("video") -> "🎬"
        m.startsWith("audio") -> "🎵"
        else -> "📄"
    }
}

@Composable
fun BoxScreen(store: Store, onExit: () -> Unit) {
    val root = remember { store.rootDoc() }
    val ctx = LocalContext.current
    var stack by remember { mutableStateOf(listOfNotNull(root)) }
    var tick by remember { mutableStateOf(0) }
    var opened by remember { mutableStateOf<DocumentFile?>(null) }
    var showNew by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<DocumentFile?>(null) }
    var deleting by remember { mutableStateOf<DocumentFile?>(null) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val dir = stack.lastOrNull()
        if (dir != null && uris.isNotEmpty()) {
            thread { uris.forEach { runCatching { store.importInto(dir, it) } }; onMain { tick++ } }
        }
    }
    BackHandler {
        if (opened != null) opened = null
        else if (stack.size > 1) stack = stack.dropLast(1)
        else onExit()
    }
    val cur = stack.lastOrNull()
    if (cur == null) { Text("Folder tidak ditemukan", color = Color.White, modifier = Modifier.padding(24.dp)); return }
    val items = remember(cur, tick) {
        cur.listFiles().sortedWith(compareBy({ !it.isDirectory }, { it.name?.lowercase() }))
    }
    val o = opened
    if (o != null) {
        Viewer(o) { opened = null }
        return
    }
    Column(Modifier.fillMaxSize()) {
        TopBar(if (stack.size == 1) "MyBox 箱" else cur.name ?: "Folder") {
            if (stack.size > 1) stack = stack.dropLast(1) else onExit()
        }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { showNew = true }, shape = RoundedCornerShape(16.dp)) { Text("＋ Folder") }
            Button(onClick = { importer.launch(arrayOf("*/*")) }, shape = RoundedCornerShape(16.dp)) { Text("＋ File") }
        }
        Spacer(Modifier.height(8.dp))
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Masih kosong~\nBuat folder kategori: Anime, Musik, Dokumen…", color = Color(0xFFD9CFF5), textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.uri.toString() }) { f ->
                    FileRow(
                        f,
                        onOpen = { if (f.isDirectory) stack = stack + f else opened = f },
                        onRename = { renaming = f },
                        onDelete = { deleting = f }
                    )
                }
            }
        }
    }
    renaming?.let { f ->
        RenameDialog(f.name ?: "", { renaming = null }) { n ->
            renaming = null
            val ok = runCatching { f.renameTo(n) }.getOrDefault(false)
            if (!ok) Toast.makeText(ctx, "Gagal mengganti nama", Toast.LENGTH_SHORT).show()
            tick++
        }
    }
    deleting?.let { f ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Hapus ${f.name}?") },
            text = { Text(if (f.isDirectory) "Folder beserta semua isinya akan terhapus permanen." else "File akan terhapus permanen.") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    val ok = runCatching { f.delete() }.getOrDefault(false)
                    if (!ok) Toast.makeText(ctx, "Gagal menghapus", Toast.LENGTH_SHORT).show()
                    tick++
                }) { Text("Hapus", color = Color(0xFFFF6B6B)) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Batal") } }
        )
    }
    if (showNew) NewFolderDialog(onDismiss = { showNew = false }) { name ->
        showNew = false
        cur.createDirectory(name)
        tick++
    }
}

@Composable
fun NewFolderDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Folder kategori baru") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Nama folder") })
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    listOf("Anime", "Musik", "Dokumen").forEach { s -> TextButton(onClick = { name = s }) { Text(s, fontSize = 12.sp) } }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    listOf("Foto", "Video").forEach { s -> TextButton(onClick = { name = s }) { Text(s, fontSize = 12.sp) } }
                }
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onCreate(name.trim()) }) { Text("Buat") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
fun Viewer(f: DocumentFile, onClose: () -> Unit) {
    val mime = f.type ?: ""
    Column(Modifier.fillMaxSize()) {
        TopBar(f.name ?: "", onClose)
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            when {
                mime.startsWith("image") -> AsyncImage(model = f.uri, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                mime.startsWith("video") -> AndroidView(
                    factory = { c ->
                        VideoView(c).apply {
                            val mc = MediaController(c)
                            mc.setAnchorView(this)
                            setMediaController(mc)
                            setVideoURI(f.uri)
                            setOnPreparedListener { start() }
                        }
                    },
                    onRelease = { it.stopPlayback() },
                    modifier = Modifier.fillMaxSize()
                )
                mime.startsWith("audio") -> AudioPlayer(f)
                else -> Text("Format ini belum bisa dibuka di MyBox", color = Color.White)
            }
        }
    }
}

@Composable
fun AudioPlayer(f: DocumentFile) {
    val ctx = LocalContext.current
    val mp = remember { MediaPlayer().apply { setDataSource(ctx, f.uri); prepare() } }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0f) }
    DisposableEffect(Unit) { onDispose { mp.release() } }
    LaunchedEffect(playing) {
        while (playing) {
            pos = mp.currentPosition.toFloat()
            if (!mp.isPlaying) playing = false
            delay(250)
        }
    }
    val spin by rememberInfiniteTransition(label = "disc").animateFloat(
        0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "spin"
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
        Box(Modifier.size(200.dp).clip(CircleShape).background(Sakura).rotate(if (playing) spin else 0f), contentAlignment = Alignment.Center) {
            Text("🎵", fontSize = 80.sp)
        }
        Spacer(Modifier.height(24.dp))
        Slider(
            value = pos, valueRange = 0f..mp.duration.toFloat().coerceAtLeast(1f),
            onValueChange = { pos = it }, onValueChangeFinished = { mp.seekTo(pos.toInt()) }
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            if (playing) { mp.pause(); playing = false } else { mp.start(); playing = true }
        }, shape = CircleShape, modifier = Modifier.size(72.dp)) { Text(if (playing) "⏸" else "▶", fontSize = 26.sp) }
    }
}

// ---------- Share ----------
@Composable
fun ShareHome(onBack: () -> Unit, openBt: () -> Unit, openWifi: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar("Share 共有", onBack)
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            AnimeCard("青", "Bluetooth", "Kirim & terima ke HP terpasang", Sakura, openBt)
            AnimeCard("波", "WiFi", "Satu jaringan, sambung lewat QR", Mint, openWifi)
            Text("File yang diterima masuk ke folder “Diterima” di MyBox.", color = Color(0xFFD9CFF5), fontSize = 12.sp)
        }
    }
}

fun hasBtPerm(ctx: Context) =
    Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

@SuppressLint("MissingPermission")
@Composable
fun BtScreen(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val adapter = remember { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter }
    var granted by remember { mutableStateOf(hasBtPerm(ctx)) }
    var selected by remember { mutableStateOf<BluetoothDevice?>(null) }
    var tick by remember { mutableStateOf(0) }
    val perms = remember {
        buildList {
            if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = hasBtPerm(ctx) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> uris.forEach { BtHub.sendFile(it) } }
    Column(Modifier.fillMaxSize().padding(bottom = 16.dp)) {
        TopBar("Bluetooth 青歯", onBack)
        val who = BtHub.connected
        if (who != null) {
            ChatPane(who) { pick.launch(arrayOf("*/*")) }
        } else {
            Column(
                Modifier.padding(horizontal = 16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when {
                    adapter == null -> Text("Perangkat ini tidak punya Bluetooth", color = Color.White)
                    !granted -> PinkButton("Izinkan Bluetooth & notifikasi") { perm.launch(perms) }
                    !adapter.isEnabled -> {
                        Text("Bluetooth masih mati.", color = Gold)
                        PinkButton("Nyalakan Bluetooth") { ctx.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }
                        PinkButton("Cek lagi") { tick++ }
                    }
                    else -> {
                        if (BtHub.listening) PinkButton("⏹ Batal menunggu") { BtHub.stopListen() }
                        else PinkButton("📥 Terima sambungan (jadi penerima)") { BtHub.listen() }
                        PinkButton("⚙ Pasangkan perangkat baru") { ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
                        Text("Perangkat terpasang — ketuk untuk memilih tujuan:", color = Color(0xFFD9CFF5), fontSize = 13.sp)
                        val devices = remember(tick, granted) { adapter.bondedDevices.toList() }
                        devices.forEach { d ->
                            val sel = selected?.address == d.address
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                                    .background(if (sel) Sakura.copy(alpha = 0.35f) else Color(0x26FFFFFF))
                                    .clickable { selected = d }.padding(14.dp)
                            ) { Text("📱 ${d.name ?: d.address}", color = Color.White) }
                        }
                        if (devices.isEmpty()) Text("Belum ada perangkat terpasang.", color = Gold)
                        PinkButton("🔗 Hubungkan ke ${selected?.name ?: "…"}", enabled = selected != null) { selected?.let { BtHub.connect(it) } }
                        Text(
                            "Satu HP menekan Terima, HP lain menekan Hubungkan. Setelah tersambung kalian bisa chat & kirim file, dan sesi tetap jalan di latar belakang.",
                            color = Color(0xFFD9CFF5), fontSize = 12.sp
                        )
                    }
                }
                if (BtHub.status.isNotEmpty()) Text(BtHub.status, color = Mint)
            }
        }
    }
}

@Composable
fun ChatPane(who: String, pickFile: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val msgs = BtHub.messages
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Terhubung: $who", color = Mint, modifier = Modifier.weight(1f), maxLines = 1)
            TextButton(onClick = { confirmClear = true }) { Text("Hapus riwayat", color = Color(0xFFD9CFF5), fontSize = 12.sp) }
            TextButton(onClick = { BtHub.disconnect() }) { Text("Putus", color = Gold) }
        }
        if (confirmClear) AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Hapus riwayat chat?") },
            text = { Text("Semua pesan dengan perangkat ini akan dihapus dari HP ini.") },
            confirmButton = { TextButton(onClick = { confirmClear = false; BtHub.clearHistory() }) { Text("Hapus", color = Color(0xFFFF6B6B)) } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Batal") } }
        )
        if (BtHub.progress > 0f) { Text(BtHub.status, color = Color(0xFFD9CFF5), fontSize = 12.sp); ProgressBar(BtHub.progress); Spacer(Modifier.height(6.dp)) }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(msgs.size) { i ->
                val m = msgs[i]
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.mine) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(
                        m.text, color = if (m.mine) Night else Color.White,
                        modifier = Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (m.mine) Sakura else Color(0x33FFFFFF)).padding(12.dp)
                    )
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = pickFile) { Text("📎", fontSize = 22.sp) }
            OutlinedTextField(
                value = text, onValueChange = { if (it.length <= 2000) text = it },
                modifier = Modifier.weight(1f), placeholder = { Text("Ketik pesan…") }, maxLines = 3
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { BtHub.sendText(text.trim()); text = "" }, enabled = text.isNotBlank(), shape = CircleShape) { Text("➤") }
        }
    }
}

@Composable
fun WifiScreen(store: Store, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var picked by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var qr by remember { mutableStateOf<Bitmap?>(null) }
    var status by remember { mutableStateOf("") }
    var progress by remember { mutableStateOf(0f) }
    val holder = remember { arrayOfNulls<FileServer>(1) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { picked = it }
    val scan = rememberLauncherForActivityResult(ScanContract()) { r ->
        val text = r.contents ?: return@rememberLauncherForActivityResult
        val host = runCatching { URL(text).host }.getOrNull()
        if (host == null || !isLanHost(host)) { status = "QR tidak dikenali / bukan jaringan lokal"; return@rememberLauncherForActivityResult }
        status = "Menyambung…"; progress = 0f
        thread {
            try {
                val base = text.trimEnd('/')
                val list = URL("$base/list").readText().lines().filter { it.isNotBlank() }
                list.forEach { line ->
                    val (idx, name, size) = line.split("\t")
                    val c = URL("$base/f/$idx").openConnection() as HttpURLConnection
                    c.inputStream.use { ins -> store.receive(name, ins, size.toLong()) { p -> onMain { status = "Mengunduh $name"; progress = p } } }
                }
                onMain { status = "Selesai ${list.size} file ✓ (folder Diterima)"; progress = 1f }
            } catch (e: Exception) { onMain { status = "Gagal: ${e.message}" } }
        }
    }
    DisposableEffect(Unit) { onDispose { holder[0]?.stop() } }
    Column(Modifier.fillMaxSize().padding(bottom = 16.dp)) {
        TopBar("WiFi 波", onBack)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("QR (Kirim)", "Scan (Terima)").forEachIndexed { i, t ->
                Button(
                    onClick = { tab = i }, shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (tab == i) Sakura else Color(0x33FFFFFF), contentColor = if (tab == i) Night else Color.White)
                ) { Text(t) }
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (tab == 0) {
                PinkButton("Pilih file yang dikirim (${picked.size})") { pick.launch(arrayOf("*/*")) }
                PinkButton("Buat QR", enabled = picked.isNotEmpty()) {
                    holder[0]?.stop()
                    val ip = localIp()
                    if (ip == null) { status = "Sambungkan ke WiFi / hotspot dulu" } else {
                        val srv = FileServer(ctx, picked)
                        val port = srv.start()
                        holder[0] = srv
                        qr = BarcodeEncoder().encodeBitmap("http://$ip:$port", BarcodeFormat.QR_CODE, 700, 700)
                        status = "Minta HP lain membuka Scan lalu arahkan ke QR ini"
                    }
                }
                qr?.let {
                    androidx.compose.foundation.Image(
                        bitmap = it.asImageBitmap(), contentDescription = "QR",
                        modifier = Modifier.size(260.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(8.dp)
                    )
                }
            } else {
                PinkButton("📷 Scan QR") {
                    scan.launch(ScanOptions().setPrompt("Arahkan ke QR dari HP pengirim").setBeepEnabled(false).setOrientationLocked(false))
                }
                if (progress > 0f) ProgressBar(progress)
            }
            if (status.isNotEmpty()) Text(status, color = Mint, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun FileRow(f: DocumentFile, onOpen: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0x26FFFFFF))
            .clickable(onClick = onOpen).padding(start = 14.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(emojiFor(f), fontSize = 26.sp)
        Spacer(Modifier.width(12.dp))
        Text(f.name ?: "?", color = Color.White, maxLines = 2, modifier = Modifier.weight(1f))
        Box {
            TextButton(onClick = { menu = true }) { Text("⋮", color = Color.White, fontSize = 22.sp) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("✏️ Ganti nama") }, onClick = { menu = false; onRename() })
                DropdownMenuItem(text = { Text("🗑 Hapus") }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

@Composable
fun RenameDialog(current: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ganti nama") },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
        confirmButton = { TextButton(enabled = name.isNotBlank() && name != current, onClick = { onOk(name.trim()) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
