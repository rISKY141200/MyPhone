package com.rizky.myphone

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.sin

val Sakura = Color(0xFFFF8FB8)
val Night = Color(0xFF1B1035)
val Indigo = Color(0xFF3A2A6B)
val Gold = Color(0xFFFFD36E)
val Mint = Color(0xFF7DE3D1)

@Composable
fun MyPhoneTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Sakura, secondary = Mint, tertiary = Gold,
            background = Night, surface = Indigo,
            onPrimary = Night, onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}

@Composable
fun SakuraBackground(content: @Composable BoxScope.() -> Unit) {
    val transition = rememberInfiniteTransition(label = "petals")
    val t by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "t"
    )
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF2B1B5A), Night, Color(0xFF3B1F4F))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            for (i in 0 until 16) {
                val seed = (i * 0.6180339f) % 1f
                val x = seed * size.width + sin(t * 6.2832f + i) * 24f
                val y = ((t + i / 16f) % 1f) * size.height
                rotate(degrees = t * 360f + i * 30f, pivot = Offset(x, y)) {
                    drawOval(Color(0x66FFB7D5), topLeft = Offset(x - 8f, y - 5f), size = Size(16f, 10f))
                }
            }
        }
        content()
    }
}
