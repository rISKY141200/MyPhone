package com.rizky.myphone

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import kotlin.math.sin

val Night = Color(0xFF12101F)
val Gold = Color(0xFFFFC857)
val Mint = Color(0xFF5FD8C0)
val TextDim = Color(0xFFB9B4CF)

val THEMES = listOf(
    "Sakura" to Color(0xFFFF8FB8),
    "Biru" to Color(0xFF64B5F6),
    "Hijau" to Color(0xFF4DD0A8),
    "Ungu" to Color(0xFFB388FF),
    "Oranye" to Color(0xFFFFB74D),
    "Merah" to Color(0xFFFF6B6B)
)
val CHAT_COLORS = listOf("#1B1035", "#0F2A3D", "#10281F", "#2B1620", "#000000")

val Accent: Color get() = UiPrefs.accent

object UiPrefs {
    private var sp: SharedPreferences? = null
    var themeIdx by mutableStateOf(0)
    var chatBg by mutableStateOf("default")

    val accent: Color get() = THEMES[themeIdx.coerceIn(0, THEMES.lastIndex)].second

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("ui", Context.MODE_PRIVATE)
        sp = p
        themeIdx = p.getInt("theme", 0)
        chatBg = p.getString("chatbg", "default") ?: "default"
    }

    fun setTheme(i: Int) { themeIdx = i; sp?.edit()?.putInt("theme", i)?.apply() }
    fun setChatBg(v: String) { chatBg = v; sp?.edit()?.putString("chatbg", v)?.apply() }
}

@Composable
fun MyPhoneTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = UiPrefs.accent, secondary = Mint, tertiary = Gold,
            background = Night, surface = Color(0xFF1E1B33),
            onPrimary = Night, onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}

@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val transition = rememberInfiniteTransition(label = "petals")
    val t by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "t"
    )
    val acc = UiPrefs.accent
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(lerp(Night, acc, 0.16f), Night, lerp(Night, acc, 0.08f)))
        )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            for (i in 0 until 9) {
                val seed = (i * 0.6180339f) % 1f
                val x = seed * size.width + sin(t * 6.2832f + i) * 24f
                val y = ((t + i / 9f) % 1f) * size.height
                rotate(degrees = t * 360f + i * 40f, pivot = Offset(x, y)) {
                    drawOval(acc.copy(alpha = 0.22f), topLeft = Offset(x - 8f, y - 5f), size = Size(16f, 10f))
                }
            }
        }
        content()
    }
}
